/*----------------------------------------------------------------------------*\
	MAIN
\*----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*\
	INIT
\*----------------------------------------------------------------------------*/
( function( $ ) {
	"use strict";

	var $inits = $( '.mpc-init' ),
		$rows  = $( '.vc_row.mpc-animation, .vc_column_container.mpc-animation, .mpc-toggle-row.mpc-animation' );

	_mpc_vars.$document.ready( function() {
		$inits.trigger( 'mpc.init' );

		$rows.trigger( 'mpc.inited' );
	});

	$inits.one( 'mpc.inited', function( event ) {
		event.stopPropagation();

		var $this = $( this );

		if( ! $this.is( '.mpc-animation' ) ) {
			$this
				.velocity( {
					opacity: 1
				}, {
					duration: 250,
					delay: 100,
					begin: function() {
						$this
							.addClass( 'mpc-inited' )
							.removeClass( 'mpc-init' );
					}
				});
		} else {
			$this
				.addClass( 'mpc-inited' )
				.removeClass( 'mpc-init' );
		}
	});

} )( jQuery );

/*----------------------------------------------------------------------------*\
	ANIMATIONS
\*----------------------------------------------------------------------------*/
( function( $ ) {
	"use strict";

	function init_animation( $item, _animation_in, _animation_loop, _animation_hover ) {
		if ( _animation_in != '' && ( ! _mpc_vars.breakpoints.custom( '(max-width: 768px)' ) || _mpc_vars.animations ) ) {
			var _item = new Waypoint( {
				element: $item[ 0 ],
				handler: function() {
					$item.velocity( _animation_in[ 0 ], {
						duration: parseInt( _animation_in[ 1 ] ),
						delay:    parseInt( _animation_in[ 2 ] ),
						display:  null,
						complete: function() {
							$item.css( 'transform', '' );
						}
					} );

					loop_item( $item, _animation_loop, _animation_hover );

					if ( this.destroy !== undefined ) {
						this.destroy();
					}
				},
				offset: parseInt( _animation_in[ 3 ] ) + '%'
			} );

		} else {
			$item.css( 'opacity', 1 );

			loop_item( $item, _animation_loop, _animation_hover );
		}
	}

	function loop_effect( $item, _effect, _duration, _delay, _hover ) {
		if ( _hover && $item._hover ) {
			setTimeout( function() {
				loop_effect( $item, _effect, _duration, _delay, _hover );
			}, _delay );
		} else {
			$item.velocity( _effect, {
				duration: _duration,
				display:  null,
				complete: function() {
					setTimeout( function() {
						loop_effect( $item, _effect, _duration, _delay, _hover );
					}, _delay );
				}
			} );
		}
	}

	function loop_item( $item, _animation_loop, _animation_hover ) {
		if ( _animation_loop != '' ) {
			if ( parseInt( _animation_loop[ 2 ] ) == 0 ) {
				$item.velocity( _animation_loop[ 0 ], {
					duration: parseInt( _animation_loop[ 1 ] ),
					display:  null
				} );
			} else {
				if ( _animation_hover ) {
					$item.on( 'mouseenter', function() {
						$item._hover = true;
					} ).on( 'mouseleave', function() {
						$item._hover = false;
					} );
				}

				loop_effect( $item, _animation_loop[ 0 ], parseInt( _animation_loop[ 1 ] ), parseInt( _animation_loop[ 2 ] ), _animation_hover );
			}
		}
	}

	$( 'body' ).addClass( 'mpc-loaded' );

	var $animated_items = $( '.mpc-animation' );

	$animated_items.each( function() {
		var $item            = $( this ),
			_animation_in    = $item.attr( 'data-animation-in' ),
			_animation_loop  = $item.attr( 'data-animation-loop' ),
			_animation_hover = $item.attr( 'data-animation-hover' );

		_animation_in    = typeof _animation_in != 'undefined' ? _animation_in.split( '||' ) : '';
		_animation_loop  = typeof _animation_loop != 'undefined' ? _animation_loop.split( '||' ) : '';
		_animation_hover = typeof _animation_hover != 'undefined';

		$item.one( 'mpc.inited', function() {
			init_animation( $item, _animation_in, _animation_loop, _animation_hover );
		} );
	} );
} )( jQuery );

/*----------------------------------------------------------------------------*\
	WAYPOINTS
\*----------------------------------------------------------------------------*/
( function( $ ) {
	"use strict";

	var $waypoints = $( '.mpc-waypoint' );

	$waypoints.each( function() {
		var $waypoint = $( this ),
			_inview = new Waypoint.Inview( {
				element: $waypoint[ 0 ],
				enter: function() {
					$waypoint
						.addClass( 'mpc-waypoint--init' )
						.trigger( 'mpc.waypoint' );

					setTimeout( function() {
						_inview.destroy();
					}, 10 );
				}
			} );
	} );
} )( jQuery );

/*----------------------------------------------------------------------------*\
	RESIZE
\*----------------------------------------------------------------------------*/
( function( $ ) {
	"use strict";

	var _resize_timer;

	_mpc_vars.window_width = _mpc_vars.$window.width();
	_mpc_vars.window_height = _mpc_vars.$window.height();

	_mpc_vars.$window.on( 'resize', function() {
		clearTimeout( _resize_timer );

		_resize_timer = setTimeout( function() {
			_mpc_vars.window_width = _mpc_vars.$window.width();
			_mpc_vars.window_height = _mpc_vars.$window.height();

			_mpc_vars.$window.trigger( 'mpc.resize' );
		}, 250 );
	} );
} )( jQuery );

/*----------------------------------------------------------------------------*\
	VC Row Stretch trigger workaround...
\*----------------------------------------------------------------------------*/
( function( $ ) {
	"use strict";

	var $rows = $( '[data-vc-full-width="true"]' );

	function mpc_stretch_row_trigger( $row ) {
		if( $row.attr( 'data-vc-full-width-init' ) == 'true' ) {
			$row.trigger( 'mpc.rowResize' );
		} else {
			setTimeout( function() {
				mpc_stretch_row_trigger( $row );
			}, 100 );
		}
	}

	$.each( $rows, function() {
		mpc_stretch_row_trigger( $( this ) );
	} );

} )( jQuery );
